#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/select.h>

int main(int argc, char*argv[]) {
   int TOTAL = 0;
   int buf = 0;
   int fd1 = 0;
   int fd2 = 0;
   struct stat buff;
   fd_set read_fd_set, active_fd_set;
   
   if(stat("ATM1", &buff) == -1) {
   if(mkfifo("ATM1", 0666) != 0){
       perror("pipe error\n");
       exit(-1);
   }
   }

   fd1 = open("ATM1", O_RDONLY | O_NONBLOCK);
   
   if(stat("ATM2", &buff) == -1) {
   if(mkfifo("ATM2", 0666) != 0){
       perror("pipe error\n");
       exit(-1);
   }
   }

   fd2 = open("ATM2", O_RDONLY | O_NONBLOCK);
   

  if(fd1 == -1 || fd2 == -1){
      perror("open error\n");
      exit(-1);
  }

   while(1) {
    FD_ZERO(&active_fd_set);
    FD_SET(fd1, &read_fd_set);
    FD_SET(fd2, &read_fd_set);

    if(select(fd2+1, &read_fd_set, NULL, NULL, NULL) < 0) {
        printf("select error\n");
        return 0;
    }
    if(FD_ISSET(fd1, &read_fd_set)) {
        buf = 0;
        if(read(fd1, &buf, sizeof(int)) <= 0) {
            continue;
        }
            TOTAL+=buf;
            printf("TOTAL = %d\n", TOTAL);
        }
    if(FD_ISSET(fd2, &read_fd_set)) {
        buf = 0;
        if(read(fd2, &buf, sizeof(int)) <= 0) {
            continue;
        }
            TOTAL+=buf;
            printf("TOTAL = %d\n", TOTAL);
  }
}
  close(fd1);
  close(fd2);

}

