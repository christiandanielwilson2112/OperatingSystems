#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>

int main(int argc, char* argv[]) {
    int buf = 0;
    int in = 0;
    if(argv[1]) {
       in = open(argv[1], O_WRONLY | O_NONBLOCK);
    }
     
    if(in < 0) {
        perror("open error");
        exit(-1);
    }

    while(1) {
        printf("Enter a deposit greater than zero:\n");
        scanf("%d", &buf);
        if(buf < 0)
            break;
        write(in, &buf, 1);
    }

    close(in);
    return 0;
}
