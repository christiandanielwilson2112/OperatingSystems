#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/time.h>

void creatPhilosophers(int nthreads);
void *philospherThread(void *arg);
void thinking(int threadIndex);
void pickUpChopsticks(int threadIndex);
void eating(int threadIndex);
void putDownChopsticks(int threadIndex);

pthread_mutex_t *chopstick_mutex;

pthread_t *tids;
int nthreads;

int main(int argc, char *argv[]) {

    if (argc != 2) {
      fprintf(stderr,"Not exactly 1 argument\n");
      return 1;
   }
   
  nthreads = atoi(argv[1]);

  chopstick_mutex =(pthread_mutex_t *)malloc(nthreads * sizeof(pthread_mutex_t));

  printf("Christian Wilson Assignment 4: # of threads = %d\n", nthreads);
  creatPhilosophers(nthreads);
 
}

 void creatPhilosophers(int nthreads){

  	tids = (pthread_t *)malloc(nthreads*sizeof(pthread_t *));

  	 if (tids == NULL) {
    	     fprintf(stderr,"Error allocating space for %d thread ids\n",nthreads);
     	     return;
  	 }
	 int i;

        int indexArr[nthreads]; 
	 for (i=0;i<nthreads;i++){
             indexArr[i] = i;
	   if (pthread_create(tids+i,NULL,philospherThread,&indexArr[i])) {
             fprintf(stderr,"Error creating thread %d\n",i+1);
             return;
           }
         }


   for (i=0;i<nthreads;i++)
     if (pthread_join(tids[i],NULL)) {
        fprintf(stderr,"Error joining thread %d\n",i+1);
        return;
     }

    
    printf("%d threads have been joined successfully!\n", nthreads);
    return;

}

void *philospherThread(void *arg){
    int i = *(int *)arg;
    thinking(i);
    pickUpChopsticks(i);
    eating(i);
    putDownChopsticks(i);
    return;
}

void pickUpChopsticks(int threadIndex){

  pthread_mutex_lock(&chopstick_mutex[threadIndex]);
  if(threadIndex == nthreads-1)
    pthread_mutex_lock(&chopstick_mutex[0]);
  else
     pthread_mutex_lock(&chopstick_mutex[threadIndex+1]);
  printf("Philsopher %d: picked up chopsticks\n", threadIndex);

}
void putDownChopsticks(int threadIndex){
  pthread_mutex_unlock(&chopstick_mutex[threadIndex]);
  if(threadIndex == nthreads-1)
    pthread_mutex_unlock(&chopstick_mutex[0]);
  else
    pthread_mutex_unlock(&chopstick_mutex[threadIndex+1]);
  printf("Philsopher %d: put down chopsticks\n", threadIndex);

}

void thinking(int threadIndex){

    printf("Philsopher %d: start thinking\n", threadIndex);

    srand((unsigned)time(NULL));
    int random = rand() % 500;
    usleep(random);
    printf("Philsopher %d: end thinking\n", threadIndex);

}

void eating(int threadIndex){

    printf("Philsopher %d: start eating\n", threadIndex);

    srand((unsigned)time(NULL));
    int random = rand() % 500;
    usleep(random);
    printf("Philsopher %d: end eating\n", threadIndex);

}
