#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h> 
#include <sys/stat.h>

void FIFO_Scheduling();
void SJF();
void PR();
void RR(int q);
void printMetrics(int CLOCK, int Total_waiting_time, int Total_turnaround_time, int Total_job);

struct PCB {
      int ProcId;
      int ProcPR;
      int CPUburst;
      int Reg[8];
      int queueEnterClock;
      int waitingTime;
      struct PCB *next;
      };

    int CPUreg[8] = {0};
    struct PCB *Head=NULL;
    struct PCB *Tail=NULL;
    struct PCB *prev=NULL;
    struct PCB *curr=NULL;
    int CLOCK = 0; int Total_waiting_time = 0; int Total_turnaround_time = 0; int Total_job = 0;

int main(int argc, char *argv[]) {

/*
 if((strcmp(argv[0],"prog")!=0) || (strcmp(argv[1], "-arg")!=0)) { error exit(); }
 if(strcmp(argv[2], "FIFO")!=0 || strcmp(argv[2], "SJF")!=0 || strcmp(argv[2], "PR")!=0 || strcmp(argv[2], "RR")!=0) { error exit(); }
 if(strcmp(argv[argc-2], "-input")!=0) { error exit(); }
     
 printf("Please use prog -alg [FIFO|SJF|PR|RR] [-quantum [integer(ms)]] -input [input_file_name.txt]\n");
*/

 
 FILE* fp;
 char buf[2046] = "";

fp = fopen(argv[argc-1], "r");
if (fp==NULL) {
    printf("fopen fail\n");
}
while(fgets(buf, sizeof(buf), fp)) {
 curr = (struct PCB *)malloc(sizeof(struct PCB));
if(curr != NULL) {
    curr->ProcId = atoi(&buf[0]);
    curr->ProcPR = atoi(&buf[1]);
    curr->CPUburst = atoi(&buf[3]);
    curr->Reg[8] = curr->ProcId;
    curr->queueEnterClock = 0;
    curr->waitingTime = 0;
    curr->next = NULL;
    }
if(prev == NULL) {
    Head = curr;
} else {
    prev->next = curr;
}
prev = curr;
}
Tail = curr;
fclose(fp);

printf("Student Name: Christian Wilson\n");
printf("Input File Name : %s\n", argv[argc-1]);
printf("CPU Scheduling Alg : %s\n\n", argv[2]);

if(strcmp(argv[2], "FIFO") == 0) {
    FIFO_Scheduling();
} else if(strcmp(argv[2], "SJF") == 0) {
    SJF();
} else if(strcmp(argv[2], "PR") == 0) {
    PR();
} else if(strcmp(argv[2], "RR") == 0) {
    RR(atoi(argv[4]));
}

}

void printMetrics(int CLOCK, int Total_waiting_time, int Total_turnaround_time, int Total_job) { 

 printf("\nAverage Waiting time =  %.2f ms\n", (double)Total_waiting_time / Total_job);
 printf("Average Turnaround time = %.2f ms\n", (double)Total_turnaround_time / Total_job);
 printf("Throughput = %.2f jobs per ms\n", (double)Total_job / CLOCK);

}

void FIFO_Scheduling() {
  int i;
  curr = Head;
  while(curr != NULL) {
  CPUreg[8] = curr->Reg[8];
  for(i = 0; i < 8; i++) 
    CPUreg[i]++;
  curr->Reg[8] = CPUreg[8];

  curr->waitingTime = curr->waitingTime + CLOCK - curr->queueEnterClock;
  Total_waiting_time = Total_waiting_time + curr->waitingTime ;
  CLOCK = CLOCK + curr->CPUburst;
  Total_turnaround_time = Total_turnaround_time + CLOCK;
  Total_job = Total_job + 1;
  printf("Process %d is completed at %d ms\n", curr->ProcId, CLOCK);
  prev = curr;
  curr = curr->next;
  free(prev);
}
  printMetrics(CLOCK, Total_waiting_time, Total_turnaround_time, Total_job);
}

void SJF() {
   int i;
   curr = Head;
   struct PCB *shortest = Head;
   struct PCB *shortprev = NULL;
   while(curr != NULL) {
     
   while(curr->next != NULL) {
     if(shortest->CPUburst < curr->next->CPUburst) {
      shortest = curr->next;
      shortprev = curr;
   }
      curr = curr->next;
   }

    CPUreg[8] = shortest->Reg[8];
     for(i = 0; i < 8; i++)
        CPUreg[i]++;
    shortest->Reg[8] = CPUreg[8];
    
    shortest->waitingTime = shortest->waitingTime + CLOCK - shortest->queueEnterClock;
    Total_waiting_time = Total_waiting_time + shortest->waitingTime ;
    CLOCK = CLOCK + shortest->CPUburst;
    Total_turnaround_time = Total_turnaround_time + CLOCK;
    Total_job = Total_job + 1;
    printf("Process %d is completed at %d ms\n", shortest->ProcId, CLOCK);
    prev = shortest;
    shortest = shortest->next;
    shortprev->next = prev->next;
    free(shortest);
    curr = Head;
}
  printMetrics(CLOCK, Total_waiting_time, Total_turnaround_time, Total_job);
}

void PR() {
  printf("PR");
  printMetrics(CLOCK, Total_waiting_time, Total_turnaround_time, Total_job);
}

void RR(int q) {
  printf("RR");
  printMetrics(CLOCK, Total_waiting_time, Total_turnaround_time, Total_job);
}
