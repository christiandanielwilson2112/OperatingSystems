#include "pslibrary.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void part0(char *s1, char *s2) {
   strcpy(s1, "RRwwwwwRRRRRRRRR");
   strcpy(s2, "rrRRRRwwwwwwwwrrRRRRRRR");
}

void display(char *heading, char *s1, char *s2) {
    printf("\n");
    printf("%s", heading);
    printf("%s\n", s1);
    printf("%s\n", s2);
    printf("\n");
    
    int rins1 = 0;
    int rins2 = 0;
    int Rinboth = 0;
    int lens1 = 0;
    int lens2 = 0;
    double avg = 0.0;
    float Rfloat = 0.0;
    
    while(*s1 != '\0') {
        if(*s1 == 'r') {
           rins1++;
        } else if(*s1 == 'R') {
           Rinboth++;
        }
        lens1++;
        s1++;
    }
    while(*s2 != '\0') {
        if(*s2 == 'r') {
            rins2++;
        } else if(*s2 == 'R') {
            Rinboth++;
        }
        lens2++;
        s2++;
    }
    avg = (double)(rins1 + rins2) / 2; 
    if(lens1 > lens2) {
        Rfloat = (float)Rinboth / (lens1-1);
    } else if(lens2 > lens1) {
        Rfloat = (float)Rinboth / (lens2-1);
    }

    printf("%d %d %.1f %.5f\n", rins1, rins2, avg, Rfloat);
}

void fcfsa(char *s1, char *s2, int x1, int y1, int z1, int x2, int y2, int z2) {
    
   int i;
   int count1 = 0;
   int count2 = 0;
   int num = 0;
   int num2 = 0;
   for(i = 0; i < x1; i++) {
      *s1 = 'R';
      *s2 = 'r';
      s1++;
      s2++;
      count1++;
      count2++;
   }
  
   for(i = 0; i < y1; i++) {
      *s1 = 'w';
      s1++;
      count1++;
   }

   for(i = 0; i < x2; i++) {
      *s2 = 'R';
      s2++;
      count2++;
   }

   for(i = 0; i < y2; i++) {
      *s2 = 'w';
      s2++;
      count2++;
   }
   
   s2-=count2;
   s2+=count1;

   if(*s2 == 'R') {
    while(*s2 == 'R') {
      *s1 = 'r';
      s1++;
      count1++;
      s2++;
      num++;
   }
 }
   s2-=count1-num;
   s2+=count2;

   for(i = 0; i < z1; i++) {
      *s1 = 'R';
      s1++;
      count1++;
   }
  
   s1-=count1-1;
   s1+=count2;

   if(*(s1 - 1) == 'R') {
    while(*(s1 - 1) == 'R') {
     *s2 = 'r';
     s2++;
     count2++;
     s1++;
    }
   }

   for(i = 0; i < z2; i++) {
      *s2 = 'R';
      s2++;
      count2++;
   }
}
