#include "pslibrary.h"
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
 int i;
 int sum = 0;
 if(argc != 8) {
    printf("Wrong number of inputs. Please input exactly 7.\n");
    exit(0);
 }

 printf("Assignment 2 program was written by Christian Wilson\n");
 printf("inputs: ");
 for(i = 1; i < argc; i++) {
   printf("%d ", atoi(argv[i]));
   sum+=atoi(argv[i]);
 } 
 printf("\n");
 
 char s1[sum];
 char s2[sum];
 
 char *heading = "FCFS\n";
 fcfs(s1, s2, atoi(argv[2]), atoi(argv[3]), atoi(argv[4]), atoi(argv[5]), atoi(argv[6]), atoi(argv[7]));
 display(heading, s1, s2);
 
 heading = "SJF\n";
 sjf(s1, s2, atoi(argv[2]), atoi(argv[3]), atoi(argv[4]), atoi(argv[5]), atoi(argv[6]), atoi(argv[7]));
 display(heading, s1, s2);
 
 heading = "PSJF\n";
 psjf(s1, s2, atoi(argv[2]), atoi(argv[3]), atoi(argv[4]), atoi(argv[5]), atoi(argv[6]), atoi(argv[7]));
 display(heading, s1, s2);
 
 heading = "RR\n";
 rr(s1, s2, atoi(argv[1]), atoi(argv[2]), atoi(argv[3]), atoi(argv[4]), atoi(argv[5]), atoi(argv[6]), atoi(argv[7]));
 display(heading, s1, s2);

 return 0;
}
