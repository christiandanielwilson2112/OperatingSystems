#include "pslibrary.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//typedef TaskState {
    int E_TASK_READY = 0;
    int E_TASK_RUNNING = 1;
    int E_TASK_WAITING = 2;
    int E_TASK_DONE = 3;
  //   } eTaskState;
                
 static char stateChars[] = {'r','R','w',0};


void part0(char *s1, char *s2) {
   strcpy(s1, "RRwwwwwRRRRRRRRR");
   strcpy(s2, "rrRRRRwwwwwwwwrrRRRRRRR");
}

void display(char *heading, char *s1, char *s2) {
    printf("\n");
    printf("%s", heading);
    printf("%s\n", s1);
    printf("%s\n", s2);
    printf("\n");
    
    int rins1 = 0;
    int rins2 = 0;
    int Rinboth = 0;
    int lens1 = 0;
    int lens2 = 0;
    double avg = 0.0;
    float Rfloat = 0.0;
    
    while(*s1 != '\0') {
        if(*s1 == 'r') {
           rins1++;
        } else if(*s1 == 'R') {
           Rinboth++;
        }
        lens1++;
        s1++;
    }
    while(*s2 != '\0') {
        if(*s2 == 'r') {
            rins2++;
        } else if(*s2 == 'R') {
            Rinboth++;
        }
        lens2++;
        s2++;
    }
    avg = (double)(rins1 + rins2) / 2; 
    if(lens1 > lens2) {
        Rfloat = (float)(Rinboth-1) / (lens1-1);
    } else if(lens2 > lens1) {
        Rfloat = (float)(Rinboth-1) / (lens2-1);
    }

    printf("%d %d %.1f %.5f\n", rins1, rins2, avg, Rfloat);
}

void fcfs(char *s1, char *s2, int x1, int y1, int z1, int x2, int y2, int z2) {
    
   int i;                                   /* next string position (time) */
                                    /* start with both ready */
    //eTaskState state1 = E_TASK_READY;
    int state1 = E_TASK_READY;
    //eTaskState state2 = E_TASK_READY;
    int state2 = E_TASK_READY;
    int cpuLeft1 = x1;       /* P1 next CPU burst remaining */
    int cpuLeft2 = x2;       /* P2 next CPU burst remaining */
    int ioLeft1 = y1;        /* P1 next IO burst remaining, 0 if no more IO */
    int ioLeft2 = y2;        /* P2 next IO burst remaining, 0 if no more IO */
 
    for (i=0; (state1 != E_TASK_DONE) || (state2 != E_TASK_DONE); i++) {
       /* running process completes its CPU burst */
    if((state1 == E_TASK_RUNNING) && (cpuLeft1== 0)) {
                                // If process finishes all its cpu-related workload.
                                // Let's check the io of process1
    if (ioLeft1 == 0) {
       state1 = E_TASK_DONE;
       s1[i] = stateChars[state1];            /* terminate the string */
    } else
      state1 = E_TASK_WAITING;
    } else if ((state2 == E_TASK_RUNNING) && (cpuLeft2 == 0) ) {

    if (ioLeft2 == 0) {
       state2 = E_TASK_DONE;
       s2[i] = stateChars[state2];            /* terminate the string */
    } else
       state2 = E_TASK_WAITING;
    }
      
                                /* handle IO complete */
    if ((state1 == E_TASK_WAITING) && (ioLeft1 == 0)) {
       state1 = E_TASK_READY;
       cpuLeft1 = z1;
    }
    if ((state2 == E_TASK_WAITING) && (ioLeft2 == 0)) {
       state2 = E_TASK_READY;
       cpuLeft2 = z2;
    }
                                           /* if both ready, depends on algorithm */
    if ((state1 == E_TASK_READY) && (state2 == E_TASK_READY)) {
            state1 = E_TASK_RUNNING;
    }
                                              /* handle one ready and CPU available */
    else if ((state1 == E_TASK_READY) && (state2 != E_TASK_RUNNING)) {
            state1 = E_TASK_RUNNING;
    }
    else if ((state2 == E_TASK_READY) && (state1 != E_TASK_RUNNING)) {
            state2 = E_TASK_RUNNING;
    }
    
                              /* insert chars in string, but avoid putting in extra string terminators */
    if (state1 != E_TASK_DONE)
       s1[i] = stateChars[state1];
    if (state2 != E_TASK_DONE)
       s2[i] = stateChars[state2];       
                                  /* decrement counts */
    if (state1 == E_TASK_RUNNING)
        cpuLeft1--;
    if (state1 == E_TASK_WAITING)
        ioLeft1--;
    if (state2 == E_TASK_RUNNING)
        cpuLeft2--;
    if (state2 == E_TASK_WAITING)
        ioLeft2--;
      }  /* end of main for loop */                                                                                          
}

void sjf(char *s1, char *s2, int x1, int y1, int z1, int x2, int y2, int z2) {
   
   int i;                                   /* next string position (time) */
                                         /* start with both ready */
         //eTaskState state1 = E_TASK_READY;
         int state1 = E_TASK_READY;
         //eTaskState state2 = E_TASK_READY;
         int state2 = E_TASK_READY;
         int cpuLeft1 = x1;       /* P1 next CPU burst remaining */
         int cpuLeft2 = x2;       /* P2 next CPU burst remaining */
         int ioLeft1 = y1;        /* P1 next IO burst remaining, 0 if no more IO */
         int ioLeft2 = y2;        /* P2 next IO burst remaining, 0 if no more IO */
      
   for (i=0; (state1 != E_TASK_DONE) || (state2 != E_TASK_DONE); i++) {
            /* running process completes its CPU burst */
     if((state1 == E_TASK_RUNNING) && (cpuLeft1== 0)) {
                                    // If process finishes all its cpu-related workload.
                                    // Let's check the io of process1
     if (ioLeft1 == 0) {
        state1 = E_TASK_DONE;
        s1[i] = stateChars[state1];            /* terminate the string */
     } else
        state1 = E_TASK_WAITING;
     } else if ((state2 == E_TASK_RUNNING) && (cpuLeft2 == 0) ) {
     
     if (ioLeft2 == 0) {
        state2 = E_TASK_DONE;
        s2[i] = stateChars[state2];            /* terminate the string */
     } else
        state2 = E_TASK_WAITING;
     }
                                     /* handle IO complete */
     if ((state1 == E_TASK_WAITING) && (ioLeft1 == 0)) {
        state1 = E_TASK_READY;
        cpuLeft1 = z1;
     }
     if ((state2 == E_TASK_WAITING) && (ioLeft2 == 0)) {
       state2 = E_TASK_READY;
       cpuLeft2 = z2;
        }
                                               /* if both ready, depends on algorithm */
     if ((state1 == E_TASK_READY) && (state2 == E_TASK_READY)) {
         if(cpuLeft1 <= cpuLeft2) 
         state1 = E_TASK_RUNNING;
         else if(cpuLeft2 < cpuLeft1)
         state2 = E_TASK_RUNNING;
     }
                                                    /* handle one ready and CPU available */
     else if ((state1 == E_TASK_READY) && (state2 != E_TASK_RUNNING)) {
          state1 = E_TASK_RUNNING;
     }
     else if ((state2 == E_TASK_READY) && (state1 != E_TASK_RUNNING)) {
          state2 = E_TASK_RUNNING;
     }
                                    /* insert chars in string, but avoid putting in extra string terminators */
     if (state1 != E_TASK_DONE)
         s1[i] = stateChars[state1];
     if (state2 != E_TASK_DONE)
         s2[i] = stateChars[state2];
                                        /* decrement counts */
     if (state1 == E_TASK_RUNNING)
          cpuLeft1--;
     if (state1 == E_TASK_WAITING)
          ioLeft1--;
     if (state2 == E_TASK_RUNNING)
          cpuLeft2--;
     if (state2 == E_TASK_WAITING)
          ioLeft2--;
      }  /* end of main for loop */
}


void psjf(char *s1, char *s2, int x1, int y1, int z1, int x2, int y2, int z2) {
    
    int i;                                   /* next string position (time) */
                                              /* start with both ready */
          //eTaskState state1 = E_TASK_READY;
          int state1 = E_TASK_READY;
          //eTaskState state2 = E_TASK_READY;
          int state2 = E_TASK_READY;
          int cpuLeft1 = x1;       /* P1 next CPU burst remaining */
          int cpuLeft2 = x2;       /* P2 next CPU burst remaining */
          int ioLeft1 = y1;        /* P1 next IO burst remaining, 0 if no more IO */
          int ioLeft2 = y2;        /* P2 next IO burst remaining, 0 if no more IO */
     
    for (i=0; (state1 != E_TASK_DONE) || (state2 != E_TASK_DONE); i++) {
                 /* running process completes its CPU burst */
    if((state1 == E_TASK_RUNNING) && (cpuLeft1== 0)) {
                                         // If process finishes all its cpu-related workload.
                                       // Let's check the io of process1
    if (ioLeft1 == 0) {
         state1 = E_TASK_DONE;
         s1[i] = stateChars[state1];            /* terminate the string */
    } else
         state1 = E_TASK_WAITING;
    } else if ((state2 == E_TASK_RUNNING) && (cpuLeft2 == 0) ) {
    if (ioLeft2 == 0) {
         state2 = E_TASK_DONE;
         s2[i] = stateChars[state2];            /* terminate the string */
    } else
        state2 = E_TASK_WAITING;
    }
                                         /* handle IO complete */
    if ((state1 == E_TASK_WAITING) && (ioLeft1 == 0)) {
        state1 = E_TASK_READY;
        cpuLeft1 = z1;
        }
    if ((state2 == E_TASK_WAITING) && (ioLeft2 == 0)) {
        state2 = E_TASK_READY;
        cpuLeft2 = z2;
        }
         
    if((state1 == E_TASK_RUNNING) && (state2 == E_TASK_READY) && (cpuLeft2 < cpuLeft1)) {
        state2 = E_TASK_RUNNING;
        state1 = E_TASK_READY;
    } 
    else if((state2 == E_TASK_RUNNING) && (state1 == E_TASK_READY) && (cpuLeft1 < cpuLeft2)) {
        state1 = E_TASK_RUNNING;
        state2 = E_TASK_READY;
    }
        
         /* if both ready, depends on algorithm */
    if ((state1 == E_TASK_READY) && (state2 == E_TASK_READY)) {
       if(cpuLeft1 <= cpuLeft2)
           state1 = E_TASK_RUNNING;
       else if(cpuLeft2 < cpuLeft1)
           state2 = E_TASK_RUNNING;
       }
                                                         /* handle one ready and CPU available */
       else if ((state1 == E_TASK_READY) && (state2 != E_TASK_RUNNING)) {
           state1 = E_TASK_RUNNING;
       }
       else if ((state2 == E_TASK_READY) && (state1 != E_TASK_RUNNING)) {
           state2 = E_TASK_RUNNING;
       }
    
                                         /* insert chars in string, but avoid putting in extra string terminators */
       if (state1 != E_TASK_DONE)
           s1[i] = stateChars[state1];
       if (state2 != E_TASK_DONE)
           s2[i] = stateChars[state2];
                                               /* decrement counts */
       if (state1 == E_TASK_RUNNING)
            cpuLeft1--;
       if (state1 == E_TASK_WAITING)
            ioLeft1--;
       if (state2 == E_TASK_RUNNING)
            cpuLeft2--;
       if (state2 == E_TASK_WAITING)
            ioLeft2--;
       }  /* end of main for loop */
}

void rr(char *s1, char *s2, int q, int x1, int y1, int z1, int x2, int y2, int z2) {

    int i;                                   /* next string position (time) */
                                         /* start with both ready */
      //eTaskState state1 = E_TASK_READY;
      int state1 = E_TASK_READY;
      //eTaskState state2 = E_TASK_READY;
      int state2 = E_TASK_READY;
      int cpuLeft1 = x1;       /* P1 next CPU burst remaining */
      int cpuLeft2 = x2;       /* P2 next CPU burst remaining */
      int ioLeft1 = y1;        /* P1 next IO burst remaining, 0 if no more IO */
      int ioLeft2 = y2;        /* P2 next IO burst remaining, 0 if no more IO */
      int qleft = q;

    for (i=0; (state1 != E_TASK_DONE) || (state2 != E_TASK_DONE); i++) {
            /* running process completes its CPU burst */
    if((state1 == E_TASK_RUNNING) && (cpuLeft1== 0)) {
                                    // If process finishes all its cpu-related workload.
                                     // Let's check the io of process1
    if (ioLeft1 == 0) {
          state1 = E_TASK_DONE;
          s1[i] = stateChars[state1];            /* terminate the string */
    } else
          state1 = E_TASK_WAITING;
    } else if ((state2 == E_TASK_RUNNING) && (cpuLeft2 == 0) ) {
    
    if (ioLeft2 == 0) {
        state2 = E_TASK_DONE;
        s2[i] = stateChars[state2];            /* terminate the string */
    } else
        state2 = E_TASK_WAITING;
    }

                /* running process has quantum expire */
    if ((state1 == E_TASK_RUNNING) && (qleft == 0) ) {
        if((state2 == E_TASK_READY) && (cpuLeft2 > 0)) {
            state2 = E_TASK_RUNNING;
            state1 = E_TASK_READY;
            qleft = q;
        }
    }  
     if ((state2 == E_TASK_RUNNING) && (qleft == 0) ) {
        if((state1 == E_TASK_READY) && (cpuLeft1 > 0)) {
            state1 = E_TASK_RUNNING;
            state2 = E_TASK_READY;
            qleft = q;
        }
    }  

                                     /* handle IO complete */
    if ((state1 == E_TASK_WAITING) && (ioLeft1 == 0)) {
           state1 = E_TASK_READY;
           cpuLeft1 = z1;
        }
    if ((state2 == E_TASK_WAITING) && (ioLeft2 == 0)) {
        state2 = E_TASK_READY;
        cpuLeft2 = z2;
  }
                                           /* if both ready, depends on algorithm */
   if ((state1 == E_TASK_READY) && (state2 == E_TASK_READY)) {
       state1 = E_TASK_RUNNING;
   }
                                              /* handle one ready and CPU available */
   else if ((state1 == E_TASK_READY) && (state2 != E_TASK_RUNNING)) {
        state1 = E_TASK_RUNNING;
        qleft = q;
   }
   else if ((state2 == E_TASK_READY) && (state1 != E_TASK_RUNNING)) {
        state2 = E_TASK_RUNNING;
        qleft = q;
   }
                                 /* insert chars in string, but avoid putting in extra string terminators */
   if (state1 != E_TASK_DONE)
       s1[i] = stateChars[state1];
   if (state2 != E_TASK_DONE)
       s2[i] = stateChars[state2];
                                   /* decrement counts */
   qleft--;
   if (state1 == E_TASK_RUNNING)
        cpuLeft1--;
   if (state1 == E_TASK_WAITING)
        ioLeft1--;
   if (state2 == E_TASK_RUNNING)
        cpuLeft2--;
   if (state2 == E_TASK_WAITING)
        ioLeft2--;
   }  /* end of main for loop */
}

